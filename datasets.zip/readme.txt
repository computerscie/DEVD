canceluser.txt contains the index (in [1, N]) of the requests that are cancelled during five environmental changes.

DestPosition.txt contains the position of customer destination, in [0 km, 100 km].

electricityRemain.txt contains the remaining electricity of EV, in [1 kWh, 60 kWh].

PilePosition.txt, UserPosition,txt, and VehPosition.txt contain the position of charging station, customer, and EV, respectively, in [0 km, 100 km].